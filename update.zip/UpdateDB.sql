INSERT INTO UserSettings (settingKey, settingValue) SELECT 'UndyAcSkillDelay', '10' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'UndyAcSkillDelay');
INSERT INTO UserSettings (settingKey, settingValue) SELECT 'UndyAcTabDelay', '10' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'UndyAcTabDelay');
INSERT INTO UserSettings (settingKey, settingValue) SELECT 'AcceptPartyAlarm', '0' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'AcceptPartyAlarm');
INSERT INTO UserSettings (settingKey, settingValue) SELECT 'CureDB', '0' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'CureDB');
INSERT INTO UserSettings (settingKey, settingValue) SELECT 'CureDBAlarm', '0' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'CureDBAlarm');
INSERT INTO UserSettings (settingKey, settingValue) SELECT 'BreakPartyOnTownChat', '0' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'BreakPartyOnTownChat');
INSERT INTO UserSettings (settingKey, settingValue) SELECT 'BreakPartyOnTownChatAlarm', '0' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'BreakPartyOnTownChatAlarm');
INSERT INTO UserSettings (settingKey, settingValue) SELECT 'checkBoxUndyAcLoop', '0' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'checkBoxUndyAcLoop');