INSERT INTO UserSettings (settingKey, settingValue)
SELECT 'IsRandomDelay', '0'
WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'IsRandomDelay');