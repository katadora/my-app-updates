[ScreenCaptureSettings]
CREATE TABLE CreateParty (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    SettingKey TEXT NOT NULL UNIQUE,
    SettingValue TEXT NOT NULL
);

INSERT OR IGNORE INTO CreateParty (SettingKey, SettingValue) VALUES ('IsActive', '0');

INSERT INTO RectanglesSettings (name, coordinateX, coordinateY, width, height) VALUES ('CharacterInfo', 0, 0, 0, 0);
