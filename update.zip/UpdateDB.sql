[ScreenCapture]
CREATE TABLE WhellOfFun (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    SettingKey TEXT NOT NULL UNIQUE,
    SettingValue TEXT NOT NULL
);

INSERT OR IGNORE INTO WhellOfFun (SettingKey, SettingValue) VALUES ('IsActive', '0');

INSERT OR IGNORE INTO RectanglesSettings (name, coordinateX, coordinateY, width, height) VALUES ('LeftBotMenu', 0, 0, 0, 0);