[ScreenCapture]
CREATE TABLE CreateParty (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    SettingKey TEXT NOT NULL UNIQUE,
    SettingValue TEXT NOT NULL
);

INSERT OR IGNORE INTO CreateParty (SettingKey, SettingValue) VALUES ('IsActive', '0');

INSERT OR IGNORE INTO CreateParty (SettingKey, SettingValue) VALUES ('PartyMember2', '[Empty]');

INSERT OR IGNORE INTO CreateParty (SettingKey, SettingValue) VALUES ('PartyMember3', '[Empty]');

INSERT OR IGNORE INTO CreateParty (SettingKey, SettingValue) VALUES ('PartyMember4', '[Empty]');

INSERT OR IGNORE INTO CreateParty (SettingKey, SettingValue) VALUES ('PartyMember5', '[Empty]');

INSERT OR IGNORE INTO CreateParty (SettingKey, SettingValue) VALUES ('PartyMember6', '[Empty]');

INSERT OR IGNORE INTO CreateParty (SettingKey, SettingValue) VALUES ('PartyMember7', '[Empty]');

INSERT OR IGNORE INTO CreateParty (SettingKey, SettingValue) VALUES ('PartyMember8', '[Empty]');

INSERT INTO RectanglesSettings (name, coordinateX, coordinateY, width, height) VALUES ('CharacterInfo', 0, 0, 0, 0);
