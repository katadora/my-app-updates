[ScreenCapture]
CREATE TABLE IF NOT EXISTS InventorySlotAlert (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    SettingKey TEXT NOT NULL UNIQUE,
    SettingValue TEXT NOT NULL
);

[ScreenCapture]
INSERT OR IGNORE INTO InventorySlotAlert (SettingKey, SettingValue)
SELECT 'IsActive', 'false'
WHERE NOT EXISTS (
    SELECT 1 FROM InventorySlotAlert WHERE SettingKey = 'IsActive'
);

[ScreenCapture]
INSERT OR IGNORE INTO InventorySlotAlert (SettingKey, SettingValue)
SELECT 'LowSlotThreshold', '5'
WHERE NOT EXISTS (
    SELECT 1 FROM InventorySlotAlert WHERE SettingKey = 'LowSlotThreshold'
);