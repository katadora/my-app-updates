[ScreenCapture]
CREATE TABLE IF NOT EXISTS SnapNetStartGenie (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    SettingKey TEXT NOT NULL UNIQUE,
    SettingValue TEXT NOT NULL
);

[ScreenCapture]
INSERT OR IGNORE INTO StartGenie (SettingKey, SettingValue)
SELECT 'IsActive', 'false'
WHERE NOT EXISTS (
    SELECT 1 FROM StartGenie WHERE SettingKey = 'IsActive'
);