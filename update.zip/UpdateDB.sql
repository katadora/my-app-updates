INSERT INTO UserSettings (settingKey, settingValue) SELECT 'UndyAcSkillDelay', '10' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'UndyAcSkillDelay');
INSERT INTO UserSettings (settingKey, settingValue) SELECT 'UndyAcTabDelay', '10' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'UndyAcTabDelay');
INSERT INTO UserSettings (settingKey, settingValue) SELECT 'AcceptPartyAlarm', '10' WHERE NOT EXISTS (SELECT 1 FROM UserSettings WHERE settingKey = 'AcceptPartyAlarm');
