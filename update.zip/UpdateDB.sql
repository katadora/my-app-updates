﻿[SCREENCAPTURE]
CREATE TABLE IF NOT EXISTS InventorySlotAlerts (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    SettingKey TEXT NOT NULL UNIQUE,
    SettingValue TEXT NOT NULL
);

[SCREENCAPTURE]
-- IsActive kaydı yoksa ekle
INSERT OR IGNORE INTO InventorySlotAlerts (SettingKey, SettingValue)
SELECT 'IsActive', 'false'
WHERE NOT EXISTS (
    SELECT 1 FROM InventorySlotAlerts WHERE SettingKey = 'IsActive'
);

[SCREENCAPTURE]
-- LowSlotThreshold kaydı yoksa ekle
INSERT OR IGNORE INTO InventorySlotAlerts (SettingKey, SettingValue)
SELECT 'LowSlotThreshold', '5'
WHERE NOT EXISTS (
    SELECT 1 FROM InventorySlotAlerts WHERE SettingKey = 'LowSlotThreshold'
);