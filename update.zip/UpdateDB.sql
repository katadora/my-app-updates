[ScreenCapture]
CREATE TABLE WhellOfFun (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    SettingKey TEXT NOT NULL UNIQUE,
    SettingValue TEXT NOT NULL
);

INSERT OR IGNORE INTO WhellOfFun (SettingKey, SettingValue) VALUES ('IsActive', '0');